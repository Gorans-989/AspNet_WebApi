﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SedcWebApiClass05MovieApp.DomainModels.DbModels
{
    public enum Genre
    {
        Comedy = 1,
        Horror,
        Action,
        Drama,
        Other
    }
}
