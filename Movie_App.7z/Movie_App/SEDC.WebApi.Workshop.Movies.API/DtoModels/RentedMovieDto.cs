﻿namespace DtoModels
{
    public class RentedMovieDto
    {
        public MovieDto Movie { get; set; }
    }
}