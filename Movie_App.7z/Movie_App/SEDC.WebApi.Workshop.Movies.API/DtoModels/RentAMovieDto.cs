﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DtoModels
{
    public class RentAMovieDto
    {
        public int MovieId { get; set; }
        public int UserId { get; set; }
    }
}
