﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Models
{
    public class LogIn
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
