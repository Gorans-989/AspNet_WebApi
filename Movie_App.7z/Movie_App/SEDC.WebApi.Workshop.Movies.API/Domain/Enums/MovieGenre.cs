﻿namespace Domain.Enums
{
    public enum MovieGenre
    {
        Action = 1,
        Thriller,
        Comedy
    }
}
